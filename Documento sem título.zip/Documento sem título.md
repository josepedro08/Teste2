﻿Determine se os vetores dados são linearmente independentes.


1. v1 = (4,−1, 2), v2 = (−4, 10, 2)
1. v1 = (−3, 0, 4), v2 = (5, −1, 2), v3 = (1, 1, 3)
